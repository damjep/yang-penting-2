# UnoCardModel_v3 > 2023-09-02 11:12am
https://universe.roboflow.com/ivan-moskalev-uwzkq/unocardmodel_v3

Provided by a Roboflow user
License: Public Domain

